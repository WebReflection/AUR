/*
 * cog-config.h
 * Copyright (C) 2017-2018 Adrian Perez <aperez@igalia.com>
 *
 * Distributed under terms of the MIT license.
 */

#ifndef COG_CONFIG_H_IN
#define COG_CONFIG_H_IN

#define COG_VERSION_MAJOR 0
#define COG_VERSION_MINOR 8
#define COG_VERSION_PATCH 1
#define COG_VERSION_STRING "0.8.1"
#define COG_VERSION_EXTRA ""
#define COG_DEFAULT_APPID "com.igalia.Cog"
/* #undef COG_DEFAULT_HOME_URI */
#define COG_USE_WEBKITGTK 0
#define WAYLAND_1_10_OR_GREATER 1

/* FIXME: Perhaps make this a cmake define instead. */
#define COG_DEFAULT_APPNAME "Cog"

#endif /* !COG_CONFIG_H_IN */
