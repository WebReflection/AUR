/*
 * cog-config.h
 * Copyright (C) 2021 Igalia S.L.
 * Copyright (C) 2017-2018 Adrian Perez <aperez@igalia.com>
 *
 * Distributed under terms of the MIT license.
 */

#ifndef COG_CONFIG_H_IN
#define COG_CONFIG_H_IN

#define COG_VERSION_MAJOR 0
#define COG_VERSION_MINOR 10
#define COG_VERSION_PATCH 0
#define COG_VERSION_STRING "0.10.0"
#define COG_VERSION_EXTRA ""
#define COG_DEFAULT_APPID "com.igalia.Cog"
/* #undef COG_DEFAULT_HOME_URI */

/* FIXME: Perhaps make this a cmake define instead. */
#define COG_DEFAULT_APPNAME "Cog"

#endif /* !COG_CONFIG_H_IN */
